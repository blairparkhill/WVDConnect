using module .\selenium-powershell\Selenium.psd1
#using namespace system.Collections
#using namespace System.Collections.Generic
#using namespace System.Management.Automation
#using namespace System.Management.Automation.Language
<#
    .SYNOPSIS
        Launch WVD Web Client Session and start a workspace resource
    .DESCRIPTION
        The WVD Client Custom Connector launches sessions against the shared components of Azure Windows Virtual Desktop deployments (RDGateway). 
        This connector supports both the tenant login (subscribing to the feed), locating the workpsace, launching and authenticating to the workspace.

        Windows Virtual Desktop service can be deployed as either WVD Classic (Fall2019) or WVD ARM (Spring2020), each with different entrypoints.

    .PARAMETER DeploymentType
        The deploymentType for Azure Windows Virtual Desktop:
            "classic" -  WVD Classic (Fall2019)
            "arm" -  WVD ARM (Spring2020)

    .PARAMETER UserName
        The name of the user which is used to log on. Acceptable forms are down-level logon name or user principal name.

    .PARAMETER Password
        The password of the user which is used to log on.

    .PARAMETER ResourceName
        The display name of the resource to be launched.

    .PARAMETER SleepBeforeLogoff
        The time in seconds to sleep after clicking the resource and before logging off. Default is 5.

    .PARAMETER NumberOfRetries
        The number of retries when retrieving an element. Default is 30.

    .PARAMETER LogFilePath
        Directory path to where the log file will be saved. Default is SystemDrive\Temp.

    .PARAMETER LogFileName
        File name for the log file. Default is Launcher_<UserName>.log.

    .PARAMETER NoLogFile
        Specify to disable logging to a file.

    .PARAMETER NoConsoleOutput
        Specify to disable logging to the console.

    .EXAMPLE
        WVDClientCustomConnector.ps1 -DeploymentType "arm" -UserName "username@domain.com" -Password "YourSuperSecretPassword" -ResourceName "Default Desktop"
#>
Param (
     [Parameter(Mandatory=$true,Position=0)] [string]$DeploymentType,
     [Parameter(Mandatory=$true,Position=1)] [string]$UserName,
     [Parameter(Mandatory=$true,Position=2)] [string]$Password,
     [Parameter(Mandatory=$true,Position=3)] [string]$ResourceName,
     [Parameter(Mandatory=$true,Position=4)] [string]$Browser,
     [Parameter(Mandatory=$false)] [int]$SleepBeforeLogoff = 5,
     [Parameter(Mandatory=$false)] [int]$NumberOfRetries = 30,
     [Parameter(Mandatory=$false)] [string]$LogFilePath = "$env:TEMP",
     [Parameter(Mandatory=$false)] [string]$LogFileName = "Launcher_$($UserName.Replace('\','_')).log",
     [Parameter(Mandatory=$false)] [switch]$NoLogFile,
     [Parameter(Mandatory=$false)] [switch]$NoConsoleOutput
 )

# Configs #
#---------#

#Global Timeout
$Timeout = 80

$ScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

$WVD_WEBCLIENT_URL_CLASSIC = "https://rdweb.wvd.microsoft.com/webclient/index.html"
$WVD_WEBCLIENT_URL_ARM = "https://rdweb.wvd.microsoft.com/arm/webclient/index.html"

$TENANT_AUTH_PAGE_TITLE_CLASSIC = "Sign in to your account"
$TENANT_AUTH_PAGE_TITLE_ARM = "Sign in to your account"

$TENANT_AUTH_ID_USERNAME_CLASSIC = "i0116"
$TENANT_AUTH_ID_USERNAME_ARM = "i0116"

$TENANT_AUTH_INPUT_PASSWORD_CLASSIC = "i0118"
$TENANT_AUTH_INPUT_PASSWORD_ARM = "i0118"

$WORKSPACE_AUTH_PAGE_TITLE_CLASSIC = "Sign in to your account"
$WORKSPACE_AUTH_PAGE_TITLE_ARM = "Sign in to your account"

$WORKSPACE_AUTH_INPUT_USERNAME_CLASSIC = 'input[ng-model="user.userName"]'
$WORKSPACE_AUTH_INPUT_USERNAME_ARM = 'input[ng-model="user.userName"]'

$WORKSPACE_AUTH_INPUT_PASSWORD_CLASSIC = 'input[ng-model="user.password"]'
$WORKSPACE_AUTH_INPUT_PASSWORD_ARM = 'input[ng-model="user.password"]'

$WORKSPACE_AUTH_BUTTON_SUBMIT_CLASSIC = 'button[translate="BUTTON_SUBMIT"]'
$WORKSPACE_AUTH_BUTTON_SUBMIT_ARM = 'button[translate="BUTTON_SUBMIT"]'

# Problematic Classes

if ('ValidateURIAttribute' -as [type]) {
    class ValidateURIAttribute :  System.Management.Automation.ValidateArgumentsAttribute {
        [void] Validate([object] $arguments , [System.Management.Automation.EngineIntrinsics]$EngineIntrinsics) {
            $Out = $null
            if ([uri]::TryCreate($arguments, [System.UriKind]::Absolute, [ref]$Out)) { return }
            else { throw  [System.Management.Automation.ValidationMetadataException]::new('Incorrect StartURL please make sure the URL starts with http:// or https://') }
            return
        }
    }    
    class ValidateURI : ValidateURIAttribute {}
}


#if ('ValidateIsWebDriverAttribute' -as [type]) {
#    class ValidateIsWebDriverAttribute :  System.Management.Automation.ValidateArgumentsAttribute {
#        [void] Validate([object] $arguments , [System.Management.Automation.EngineIntrinsics]$EngineIntrinsics) {
#            if ($arguments -isnot [OpenQA.Selenium.Remote.RemoteWebDriver]) {
#                throw  [System.Management.Automation.ValidationMetadataException]::new('Target was not a valid web driver')
#            }
#            return
#        }
#    }
#    class ValidateIsWebDriver : ValidateIsWebDriverAttribute {}
#}

if ('OperatorTransformAttribute' -as [type]) {
    #Allow operator to use containing, matching, matches, equals etc.
    class OperatorTransformAttribute : System.Management.Automation.ArgumentTransformationAttribute {
        [object] Transform([System.Management.Automation.EngineIntrinsics]$EngineIntrinsics, [object] $InputData) {
            if ($inputData -match '^(contains|like|notlike|match|notmatch|eq|ne|gt|lt)$') {
                return $InputData
            }
            switch -regex ($InputData) {
                "^contain" { return 'contains' ; break }
                "^match" { return 'match'    ; break }
                "^n\w*match" { return 'notmatch' ; break }
                "^eq" { return 'eq'       ; break }
                "^n\w*eq" { return 'ne'       ; break }
                "^n\w*like" { return 'like'       ; break }
            }
            return $InputData
        }
    }

    class OperatorTransform : OperatorTransformAttribute {}
}

$dll1Path = Join-path -path (Join-path -path $PSScriptRoot -ChildPath 'selenium-powershell\assemblies') -ChildPath 'WebDriver.dll'
$dll2Path = Join-path -path (Join-path -path $PSScriptRoot -ChildPath 'selenium-powershell\assemblies') -ChildPath 'WebDriver.Support.dll'

Add-type @"
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
namespace SeleniumSelection {
    public class Option {
        public static bool IsMultiSelect(IWebElement element) {
            var selection = new SelectElement(element);
            return selection.IsMultiple;
        }
        public static IList<IWebElement> GetOptions(IWebElement element) {
            var selection = new SelectElement(element);
            return selection.Options;
        }
        public static void SelectByValue(IWebElement element, string value) {
            var selection = new SelectElement(element);
            selection.SelectByValue(value);
        }
        public static void DeselectByValue(IWebElement element, string value) {
            var selection = new SelectElement(element);
            selection.DeselectByValue(value);
        }
        public static void SelectByText(IWebElement element, string text, bool partialMatch = false) {
            var selection = new SelectElement(element);
            selection.SelectByText(text,partialMatch);
        }
        public static void DeselectByText(IWebElement element, string text) {
            var selection = new SelectElement(element);
            selection.DeselectByText(text);
        }
        public static void SelectByIndex(IWebElement element, int index) {
            var selection = new SelectElement(element);
            selection.SelectByIndex(index);
        }
        public static void DeselectByIndex(IWebElement element, int index) {
            var selection = new SelectElement(element);
            selection.DeselectByIndex(index);
        }
        public static void DeselectAll(IWebElement element) {
            var selection = new SelectElement(element);
            selection.DeselectAll();
        }
        public static IWebElement GetSelectedOption(IWebElement element) {
            var selection = new SelectElement(element);
            return selection.SelectedOption;
        }
        public static IList<IWebElement> GetAllSelectedOptions(IWebElement element) {
            var selection = new SelectElement(element);
            return selection.AllSelectedOptions;
        }
    }
}
"@ -ReferencedAssemblies $dll1Path, $dll2Path, mscorlib

enum SeBrowsers {
    Chrome
    Edge 
    Firefox
    InternetExplorer
    MSEdge
}

enum SeWindowState {
    Headless
    Default
    Minimized
    Maximized
    Fullscreen
}

enum SeBySelector {
    ClassName
    CssSelector
    Id
    LinkText
    PartialLinkText
    Name
    TagName
    XPath
}

enum SeBySelect {
    Index
    Text
    Value    
}


# Functions #
#----------#
# Set WVD Web Client Url
function Write-LauncherHeader {
    $infoMessage = @"
                           *****************************************************
                           *****  WVD Web Client Custom Connector Script   *****
                           *****        -Console output:     {0,-6}        *****
                           *****        -Log output:         {1,-6}        *****
                           *****************************************************
"@  -f $(-not $NoConsoleOutput),$(-not $NoLogFile)
    Write-Host $infoMessage
}

function Write-ToLauncherLog {
    Param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)] [string]$Message,
        [Parameter(Mandatory=$false)] [string]$LogFile=$($LogFilePath.TrimEnd('\') + "\$LogFileName"),
        [Parameter(Mandatory=$false)] [bool]$NoConsoleOutput=$NoConsoleOutput,
        [Parameter(Mandatory=$false)] [bool]$NoLogFile=$NoLogFile
    )
    Begin {
        if(Test-Path $LogFile -IsValid) {
            if(!(Test-Path "$LogFile" -PathType Leaf)) {
                New-Item -Path $LogFile -ItemType "file" -Force -ErrorAction Stop | Out-Null
            }
        } else {
            throw "Log file path is invalid"
        }
    }
    Process {
        $Message = [DateTime]::Now.ToString("[MM/dd/yyy HH:mm:ss.fff]: ") + $Message

        if (-not $NoConsoleOutput) {
            Write-Host $Message
        }

        if (-not $NoLogFile) {
            $Message | Out-File -FilePath $LogFile -Append
        }
    }
}

function Initialize-Script {
    Write-ToLauncherLog "Initializing Script"
    Write-Host $ScriptDirectory
    Import-Module "$ScriptDirectory\selenium-powershell\Selenium.psd1" -verbose

    try {
      . ("$ScriptDirectory\selenium-powershell\SeleniumClasses.ps1")
    }
    catch {
        Write-Host "Error while loading supporting PowerShell Scripts"
    }

    # Check for an imported type to confirm load
    if (-not ([System.Management.Automation.PSTypeName]'ValidateURIAttribute').Type)
    {
       Write-Host "No Type"
       
    }else{
       Write-Host "Type exists"
    }

    #$Script:Configuration = [System.Collections.HashTable]@{}

}

function Set-WebClientEnv {
    Write-ToLauncherLog "Initializing WVD Environment Settings"
    if ($DeploymentType -eq "classic"){

        $script:wvdWebClientUrl = $WVD_WEBCLIENT_URL_CLASSIC
        $script:tenantAuthPageTitle = $TENANT_AUTH_PAGE_TITLE_CLASSIC
        $script:tenantAuthInputUsername = $TENANT_AUTH_INPUT_USERNAME_CLASSIC
        $script:tenantAuthInputPassword = $TENANT_AUTH_INPUT_PASSWORD_CLASSIC
        $script:workspaceAuthPageTitle = $WORKSPACE_AUTH_PAGE_TITLE_CLASSIC
        $script:workspaceAuthInputUsername = $WORKSPACE_AUTH_INPUT_USERNAME_CLASSIC
        $script:workspaceAuthInputPassword = $WORKSPACE_AUTH_INPUT_PASSWORD_CLASSIC
        $script:workspaceAuthButtonSubmit = $WORKSPACE_AUTH_BUTTON_SUBMIT_CLASSIC

    }elseif ($DeploymentType -eq "arm") {

        $script:wvdWebClientUrl = $WVD_WEBCLIENT_URL_ARM
        $script:tenantAuthPageTitle = $TENANT_AUTH_PAGE_TITLE_ARM
        $script:tenantAuthInputUsername = $TENANT_AUTH_INPUT_USERNAME_ARM
        $script:tenantAuthInputPassword = $TENANT_AUTH_INPUT_PASSWORD_ARM
        $script:workspaceAuthPageTitle = $WORKSPACE_AUTH_PAGE_TITLE_ARM
        $script:workspaceAuthInputUsername = $WORKSPACE_AUTH_INPUT_USERNAME_ARM
        $script:workspaceAuthInputPassword = $WORKSPACE_AUTH_INPUT_PASSWORD_ARM
        $script:workspaceAuthButtonSubmit = $WORKSPACE_AUTH_BUTTON_SUBMIT_CLASSIC

    }else {
        Write-Host "DeploymentType must be either classic or arm"
        Exit
    }
}

function Initialize-Browser {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)][string]$Browser,
        [Parameter(Mandatory=$true)][string]$Url
    )

    Write-ToLauncherLog "Initializing Browser"
    Start-SeDriver -Browser $Browser

    # Navigate to Start Page
    Set-SeUrl $Url
}

function Invoke-TenantLogin {
    # Validate Page
    Write-ToLauncherLog "Validating Tenant Auth Page Title"

    do {
        Write-ToLauncherLog "Checking for Page Title"
        Start-Sleep 1
    } until ((Get-SeDriver).SeTitle -ne "")

    If((Get-SeDriver).SeTitle -eq $tenantAuthPageTitle){
        Write-ToLauncherLog "Auth Page Validated"

        # Username
        do {
            $waitUser = Get-SeElement -By Name -Value 'loginfmt' -Timeout $Timeout -ErrorAction SilentlyContinue
        } until ($waitUser)
        Write-ToLauncherLog "response: $waitUser"

        if($waitUser){
            Write-ToLauncherLog "Sending Username"
            $waitUser.SendKeys($UserName)
        }

        # Click Next
        do {
            $waitPass = Get-SeElement -By CSS -Value 'input[value="Next"]' -Timeout $Timeout -ErrorAction SilentlyContinue
        } until ($waitPass)

        Write-ToLauncherLog "Click Next"
        Get-SeElement -By CSS -Value 'input[value="Next"]' | Invoke-SeClick

        # Password
        do {
            $waitPass = Get-SeElement -By Name -Value "passwd" -Timeout $Timeout -ErrorAction SilentlyContinue
        } until ($waitPass)

        if($waitPass){
            Write-ToLauncherLog "Sending Password"
            $waitPass.SendKeys($Password)
        }

        do {
            $waitPass = Get-SeElement -By CSS -value 'input[value="Sign in"]' -Timeout $Timeout -ErrorAction SilentlyContinue
        } until ($waitPass)

        Write-ToLauncherLog "Click Sign in"
        Get-SeElement -By CSS -value 'input[value="Sign in"]' -Timeout $Timeout -ErrorAction SilentlyContinue | Invoke-SeClick

        # Stay Signed In? No
        if ($DeploymentType -eq "arm"){
        Write-ToLauncherLog "Choosing to NOT Stay Logged in"

            do {
                $waitDialogBox = Get-SeElement -By CSS -Value "input[value=No]" -Timeout $Timeout -ErrorAction SilentlyContinue
            } until ($waitDialogBox)
        
            if($waitDialogBox){
                $waitDialogBox.Click()
            }
        }

    } else {
        Write-ToLauncherLog "Auth Page Did not Validate"
    }

}

function Invoke-LaunchResource {
    Write-ToLauncherLog "Launching Resource"

    $verifyInvokeResource = 'div[title="' + $ResourceName + '"]'

    do {
        $waitResource = Get-SeElement -By CSS -Value $verifyInvokeResource -Timeout $Timeout -ErrorAction SilentlyContinue
    } until ($waitResource)
    
    (Get-SeElement -By CSS -Value $verifyInvokeResource).Click() 

    # Allow Local Resources? Allow
    Write-ToLauncherLog "Chosing to Allow local resource access"
    do {
        $waitResourceDialog = Get-SeElement -By CSS -Value 'button[translate="BUTTON_ALLOW"]' -Timeout $Timeout -ErrorAction SilentlyContinue
    } until ($waitResourceDialog)

    (Get-SeElement -By CSS -Value 'button[translate="BUTTON_ALLOW"]').Click()
}

function Invoke-WorkspaceLogin {
    # Wait for prompt
    Write-ToLauncherLog "Waiting for Workspace Auth"

    # Username
    do {
        $waitWorkspaceUser = Get-SeElement -by CSS -Value 'input[ng-model="user.userName"]' -Timeout $Timeout -ErrorAction SilentlyContinue
    } until ($waitWorkspaceUser)

    if($waitWorkspaceUser){
        Write-ToLauncherLog "Sending Username"
        (Get-SeElement -by CSS -Value 'input[ng-model="user.userName"]').SendKeys($UserName)
    }

    # Password
    do {
        $waitWorkspacePass = Get-SeElement -by CSS -Value 'input[ng-model="user.password"]' -Timeout $Timeout -ErrorAction SilentlyContinue
    } until ($waitWorkspacePass)

    if($waitWorkspacePass){
        Write-ToLauncherLog "Sending Password"
        (Get-SeElement -by CSS -Value 'input[ng-model="user.password"]').SendKeys($Password)
    }

    # Submit
    do {
        $waitResourceDialog = Get-SeElement -By CSS -Value 'button[translate="BUTTON_SUBMIT"]' -Timeout $Timeout -ErrorAction SilentlyContinue
    } until ($waitResourceDialog)

    (Get-SeElement -By CSS -Value 'button[translate="BUTTON_SUBMIT"]').Click()

}

function Invoke-VerifyLaunch {
    Write-ToLauncherLog "Verifying Launch"

    $resourceLaunchValue = 'div[aria-label="' + $ResourceName + '"]'

    do {
        $waitLaunch = Get-SeElement -by CSS -Value $resourceLaunchValue -Timeout $Timeout -ErrorAction SilentlyContinue
     } until ($waitLaunch)

    if ($waitLaunch.Text -eq $ResourceName) {
        Write-ToLauncherLog "Launch Successful"
        $script:Launch = "Success"
    }

}

function Invoke-WaitForSignout {
    Write-ToLauncherLog "Waiting for the page to return to start (Sign out)"

    $verifySignoutResource = 'div[title="' + $ResourceName + '"]'

    if($script:Launch -eq "Success"){
        do {
            $waitSignout = Get-SeElement -By CSS -Value $verifySignoutResource -ErrorAction SilentlyContinue
            Start-Sleep 1
        } until ($waitSignout)
    }

}

# WORKFLOW #
#----------#

try {
    Write-ToLauncherLog "*************** LAUNCHER SCRIPT BEGIN ***************"
    Write-LauncherHeader

    # Initialize Connector Script/Envinonment
    Initialize-Script

    # Initialize Browser Session (Session Cleanup happens in "finally" clause)
    Set-WebClientEnv
    Initialize-Browser $Browser $wvdWebClientUrl

    # WVD tenant/feed Login
    Invoke-TenantLogin

    # Launch Resource
    Invoke-LaunchResource

    # Workspace Login (ADDS)
    Invoke-WorkspaceLogin

    # Verify Launch Success
    Invoke-VerifyLaunch

    #Wait for signout to complete?
    Invoke-WaitForSignout

}
catch {
    Write-ToLauncherLog "Exception caught by script"
    $_.ToString() | Write-Host
    $_.InvocationInfo.PositionMessage | Write-Host
    throw $_
}
finally {
    Write-ToLauncherLog "All commands complete. Shutting down"
    Stop-SeDriver
    Write-ToLauncherLog "***************  LAUNCHER SCRIPT END  ***************"
}