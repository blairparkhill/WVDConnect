# WVD Webclient Custom Connector
The WVD Webclient Custom Connector is a Login Enterprise custom connector build in Powershell and Selenium.

# Dependencies
If you clone the repo, clone with subs. This project will leverage the awesome selenium-powershell project by Adam Driscoll (v4.0.0-preview1), and by virtue inherets the dependencies therein. This is not a requirement of course, but this project may make some assumptions based on selenium-powershell and selenium-powershell is a submodule.

# Installation
## Downloading vs Cloning
### What's the difference between downloading and cloning a repository?
Cloning a repository copies the source files of a remote repository to your local machine, as well as the repository's Git history (branches, commits, tags, etc.). Cloning also creates a remote connection (usually called origin) pointing back to the cloned repository. You can only clone into a local directory that is a properly initialized Git repository (using the git init command).

Downloading a repository archive only copies a repository's source files from a specific point in time, depending on what was chosen to be copied. The biggest difference to downloading an archive is that you are not copying the repository history, or creating a connection to the remote repository. You are only getting the source files, and none of the Git metadata stored in the .git directory.

If you download a zip, you will also need to download selenuim -powershell from https://github.com/adamdriscoll/selenium-powershell, unblock, unzip, rename and replace the empty directory "selenium-powershell" directory with this newly unzipped directory of the same name.

## Clone Repo
To install, clone this repo (optionally with --recurse-submodules) on your launcher and use the configuration file to point to the selenium-powershell instance.

## Download Zip of Repo
You can download an archive of source files. D download your source as a .zip file from the actions dropdown menu from the Source view.

### Download your source as a .zip file
To download a repository archive of a branch:

Go to the Source view.
Using the branch selector to choose the master branch.
Click the actions dropdown next to the branch selector, then select Download.
Unblock the download (right-click, properties, unblock)
Unzip and rename

# Configure Login Enterprise
1. We will set this up on one launcher to test.  Once we validate functionality this deployment can be duplicated onto additional launchers.

2. The script will be run on your Launcher component under the context of the user logged into this dedicated machine.  For information on launchers look here: https://support.loginvsi.com/hc/en-us/articles/360001341959-Launchers

3. Copy your binaries for the WVD Webclient Custom Connector to your launcher install location:
C:\Program Files\Login VSI\Login PI 3 Launcher\WVDConnector

4. Within the management console select "Manage Tests".  Under "Application Test" select "Create a new Application Test". KB on information about "Application Testing": https://support.loginvsi.com/hc/en-us/articles/360012843980-Manage-Tests-Application-Testing

5. The connector you will select is "Custom connector".  This will allow you to call ANY script or executable trigged by your test schedule. KB information on custom connectors: https://support.loginvsi.com/hc/en-us/articles/360003657600-Connectors-and-connection-configuration#h_e13bf2c8-2838-4272-ad8e-96bb537213fa

6. The variables you will be able to pass from the management console are {host}, {username}, {password} and domain.  This will enable our custom connector to receive the necessary authentication parameters to facilitate our connection in your Windows Virtual Desktop test bed.

7. In the "Connection command line" field you will use the following:
%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -file "C:\Program Files\Login VSI\Login PI 3 Launcher\WVDClientCustomConnector.ps1 -DeploymentType "arm" -UserName "{username}@{domain}" -Password "{password}" -ResourceName "{host}"

8. Select the "Accounts" group, and "Launchers" group that you desire to test with.  This will specify the user accounts, and locations available to this specific testing configuration.

9. From your launcher machine take this command line string and replace the {variables} with their literal values.  Execute this command from "cmd" and watch to make sure it works successfully.  Tweak your command line string as necessary.

10. Now that you know that your string works, and you have created your testing profile run the "Application Test" from our "Manage Tests" portion of the web interface.  This is done by press the green play button.

11.  If you have any questions about configuring your environment for custom connectors, or general questions please reach out to support@loginvsi.com.  They will do their best to provide insightful guidance.
 
12. Note this is not officially supported by Login VSI.  However, support engineering will do their best to ensure that you are successful.  Happy testing.

# License

This project uses the permissive MIT License

# Contributing

When contributing to this repository, please first discuss the change you wish to make via issue,
email, or any other method with the owners of this repository before making a change. 

Please note we have a code of conduct, please follow it in all your interactions with the project.

## Pull Request Process

1. Ensure any install or build dependencies are removed before the end of the layer when doing a 
   build.
2. Update the README.md with details of changes to the interface, this includes new environment 
   variables, exposed ports, useful file locations and container parameters.
3. Increase the version numbers in any examples files and the README.md to the new version that this
   Pull Request would represent. The versioning scheme we use is [SemVer](http://semver.org/).
4. You may merge the Pull Request in once you have the sign-off of two other developers, or if you 
   do not have permission to do that, you may request the second reviewer to merge it for you.

## Code of Conduct

### Our Pledge

In the interest of fostering an open and welcoming environment, we as
contributors and maintainers pledge to making participation in our project and
our community a harassment-free experience for everyone, regardless of age, body
size, disability, ethnicity, gender identity and expression, level of experience,
nationality, personal appearance, race, religion, or sexual identity and
orientation.

### Our Standards

Examples of behavior that contributes to creating a positive environment
include:

* Using welcoming and inclusive language
* Being respectful of differing viewpoints and experiences
* Gracefully accepting constructive criticism
* Focusing on what is best for the community
* Showing empathy towards other community members

Examples of unacceptable behavior by participants include:

* The use of sexualized language or imagery and unwelcome sexual attention or
advances
* Trolling, insulting/derogatory comments, and personal or political attacks
* Public or private harassment
* Publishing others' private information, such as a physical or electronic
  address, without explicit permission
* Other conduct which could reasonably be considered inappropriate in a
  professional setting

### Our Responsibilities

Project maintainers are responsible for clarifying the standards of acceptable
behavior and are expected to take appropriate and fair corrective action in
response to any instances of unacceptable behavior.

Project maintainers have the right and responsibility to remove, edit, or
reject comments, commits, code, wiki edits, issues, and other contributions
that are not aligned to this Code of Conduct, or to ban temporarily or
permanently any contributor for other behaviors that they deem inappropriate,
threatening, offensive, or harmful.

### Scope

This Code of Conduct applies both within project spaces and in public spaces
when an individual is representing the project or its community. Examples of
representing a project or community include using an official project e-mail
address, posting via an official social media account, or acting as an appointed
representative at an online or offline event. Representation of a project may be
further defined and clarified by project maintainers.

### Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported by contacting the project team at [INSERT EMAIL ADDRESS]. All
complaints will be reviewed and investigated and will result in a response that
is deemed necessary and appropriate to the circumstances. The project team is
obligated to maintain confidentiality with regard to the reporter of an incident.
Further details of specific enforcement policies may be posted separately.

Project maintainers who do not follow or enforce the Code of Conduct in good
faith may face temporary or permanent repercussions as determined by other
members of the project's leadership.

### Attribution

This Code of Conduct is adapted from the [Contributor Covenant][homepage], version 1.4,
available at [http://contributor-covenant.org/version/1/4][version]

[homepage]: http://contributor-covenant.org
[version]: http://contributor-covenant.org/version/1/4/